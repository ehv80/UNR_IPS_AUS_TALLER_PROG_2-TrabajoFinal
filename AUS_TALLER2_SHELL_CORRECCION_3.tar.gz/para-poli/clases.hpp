#ifndef __CLASES_H
#define __CLASES_H

#include <iostream>

using namespace std;

enum modo {__Fork, __Exec};

class Accion {
public:
	virtual ~Accion() {}
	virtual int exec(enum modo)=0;
};
class Pwd: public Accion {
public:
	int exec(enum modo) {
		cout<<get_current_dir_name()<<'\n';
		return 0;
	}
};
class Cd: public Accion {
	char *dir;
public:
	Cd(char *dir): dir(dir) {}
	~Cd() { delete dir; }
	int exec(enum modo);
};
class Logout: public Accion {
public:
	int exec(enum modo) { exit(0); return 0; }
};
class Comando: public Accion {
	char *prog, **args;
	static char *path(char *);
public:
	Comando(char *prog, char **args): prog(prog), args(args) {}
	~Comando();
	int exec(enum modo);
};
class Pipe: public Accion {
	Accion *i, *d;
public:
	Pipe(Accion *i, Accion *d): i(i), d(d) {}
	~Pipe() { delete i; delete d; }
	int exec(enum modo);	
};
class RedirE: public Accion {
	Accion *p;
	char *arch;
public:
	RedirE(Accion *p, char *arch): p(p), arch(arch) {}
	~RedirE() { delete p; delete arch; }
	int exec(enum modo);	
};
class RedirS: public Accion {
	Accion *p;
	char *arch;
	bool app;
public:
	RedirS(Accion *p, char *arch, bool app): p(p), arch(arch), app(app) {}
	~RedirS() { delete p; delete arch; }
	int exec(enum modo);	
};
class And: public Accion {
	Accion *i, *d;
public:
	And(Accion *i, Accion *d): i(i), d(d) {}
	~And() { delete i; delete d; }
	int exec(enum modo);
};
class Or: public Accion {
	Accion *i, *d;
public:
	Or(Accion *i, Accion *d): i(i), d(d) {}
	~Or() { delete i; delete d; }
	int exec(enum modo);
};
class Secuencia: public Accion {
	Accion *i, *d;
public:
	Secuencia(Accion *i, Accion *d): i(i), d(d) {}
	~Secuencia() { delete i; delete d; }
	int exec(enum modo);	
};
class Subshell: public Accion {
	Accion *a;
public:
	Subshell(Accion *a): a(a) {}
	~Subshell() { delete a; }
	int exec(enum modo);	
};
#endif
