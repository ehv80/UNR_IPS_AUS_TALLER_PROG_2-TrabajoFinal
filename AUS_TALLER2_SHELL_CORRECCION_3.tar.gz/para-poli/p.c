int main() { *(char*)0=0; return 1; }
