#include <iostream>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <string.h>
#include <fcntl.h>
#include <errno.h>
#include <glob.h>

using namespace std;

#include "clases.hpp"

#define OPC1	(GLOB_TILDE|GLOB_NOCHECK)
#define OPC2	(OPC1|GLOB_APPEND)

#define FORK(x)		({ int i=fork(); cerr<<x<<" "<<i<<'\n'; i; })

static void error(const char *s, int err)
{
	char b[MAX_CANON];
	strerror_r(err, b, sizeof(b));
	cerr<<s<<": "<<b<<'\n';
}
static void glob_error(int err)
{
	cerr<<"glob: ";
	switch(err) {
	case GLOB_NOSPACE:
		cerr<<"nospace!"; break;
	case GLOB_ABORTED:
		cerr<<"aborted!"; break;
	case GLOB_NOMATCH:
		cerr<<"nomatch!"; break;
	default: cerr<<"oops!";
	}
	cerr<<'\n';
}
int Cd::exec(enum modo) {
	glob_t g;
	int r;
	if((r=glob(dir, GLOB_NOCHECK|GLOB_TILDE, NULL, &g)))//BUSCA TODOS LOS NOMBRES DE CAMINO DE
		glob_error(r);				    //FICHERO QUE CONCUERDEN CON dir
	if(chdir(g.gl_pathv[0]))
		error("cd", errno);
	return 0;
}
char *Comando::path(char *p)
{
	char *tmp=new char[1024];
	if(strchr(p, '/')!=0) {
		strcpy(tmp, p);
		return tmp;
	}
	char env[1024];
	strcpy(env, getenv("PATH"));
	char *pc=strtok(env, ":");
	do {
		strcat(strcat(strcpy(tmp, pc), "/"), p);
		if(access(tmp, X_OK)==0)
			return tmp;
	} while((pc=strtok(0, ":"))!=0);
	return p;
}
Comando::~Comando() {
	delete prog;			//Tercera prueba: 21-12-2006
	//for(int i=0; args[i]; i++)  ERROR: EN LUGAR DE CERO DEBE IR UNO.
	for(int i=1; args[i]; i++)	//BORRANDO LOS ARGUMENTOS QUE TOMA UN COMANDO
		delete args[i];
	delete args;
}
int Comando::exec(enum modo m)
{
	prog=path(prog);
	if(m==__Fork && FORK("Comando")!=0) {
		int status;
		wait(&status);
		return status;
	}
	glob_t pg;
	int r;
	if((r=glob(args[0], OPC1, NULL, &pg)))
		glob_error(r);
	for(int i=1; args[i]; i++)
		if((r=glob(args[i], OPC2, NULL, &pg)))
			glob_error(r);
	execv(prog, pg.gl_pathv);
	exit(-1);//NO SE LLEGA A EJECUTAR
	return 0;//NO SE LLEGA A EJECUTAR
}
int Pipe::exec(enum modo m)
{
	int pip[2];
	if(m==__Fork && fork()!=0)
		wait(NULL);	//PADRE
	else {
		if(pipe(pip)) {	//HIJO
			error("pipe", errno);
			exit(-1);
		}
		if(FORK("Pipe 2")!=0) {//NIETO
			dup2(pip[1], 1);//HACE QUE FILE DESCRIPTOR 1 SEA LA COPIA DE FILE DESCRIPTOR pip[1]
					//CERRANDO PRIMERO 1 SI ES NECESARIO 
			close(pip[0]);
			close(pip[1]);
			return i->exec(__Exec);
		}
		else {		//HIJO
			// completar
			/* Primera prueba: 17-12-2006 */
			dup2(pip[0], 0);
			close(pip[1]);
			close(pip[0]);
			return d->exec(__Exec);
		}
		exit(-1);
	}
	return 0;
}
int RedirE::exec(enum modo m)
{
	// completar
	/* Primera prueba: 17-12-2006 */
	/* Segunda prueba: 20-12-2006 */
	int fd, status;
	pid_t childpid;
	childpid = fork();
	cerr << "RedirE" << " " << childpid << '\n';
	switch( childpid )
	{
		case 0:	//CODIGO QUE EJECUTA PROCESO HIJO
			if( (fd = open( arch, O_RDONLY, 0666 )) == -1)
			{
				perror("ERROR EN RedirE::exec AL HACER open !");
				exit(EXIT_FAILURE);
				return -1;
			}
			close(0); //CIERRA File Descriptor 0 - STDIN - 0 QUEDA LIBRE
			dup(fd);  //QUEDA   "        "     0 - arch
				  //QUEDA   "        "    fd - arch
			close(fd);//CIERRA  "        "    fd - arch - fd QUEDA LIBRE
			return p->exec(__Exec);
			break;
		case -1:
			//CODIGO QUE EJECUTA PADRE EN CASO DE ERROR AL HACER fork
			perror("ERROR AL HACER fork EN RedirE::exec !");
			exit(EXIT_FAILURE);
			return -1;
			break;
		default://CODIGO QUE EJECUTA PADRE EN CASO DE HACER fork SATISFACTORIAMENTE
			wait(&status); //ESPERA Y GUARDA status del PROCESO HIJO
			return status;
			break;
	}
	return 0;	
}
int RedirS::exec(enum modo m)
{
	// completar
	/* Primera prueba: 17-12-2006 */
	/* Segunda prueba: 20-12-2006 */
	int fd, status;
	pid_t childpid;
	childpid = fork();
	cerr << "RedirS " << childpid << '\n';
	switch( childpid )
	{
		case 0: //CODIGO QUE EJECUTA PROCESO HIJO
			if( app == false )	//MODO DESTRUCTIVO: NO AGREGA AL FINAL, REEMPLAZA
			{
				if( (fd = open( arch, O_WRONLY|O_CREAT|O_TRUNC , 0666 )) == -1)
				{
					perror("ERROR EN RedirS::exec AL HACER open !");
					exit(EXIT_FAILURE);
					return -1;
				}
				close(1); //CIERRA File descriptor 1 - STDOUT - 1 QUEDA LIBRE
				dup(fd);  // File descriptor 1  - arch
					  // File descriptor fd - arch
				close(fd);// CIERRA File descriptor fd - arch - fd QUEDA LIBRE
				return p->exec(__Exec);
			}
			else if( app == true ) //MODO APPEND: NO DESTRUCTIVO, AGREGA AL FINAL
			{
				if( (fd = open( arch, O_WRONLY|O_CREAT|O_APPEND , 0666 )) == -1)
				{
					perror("ERROR EN RedirS::exec AL HACER open !");
					exit(EXIT_FAILURE);
					return -1;
				}
				close(1); //CIERRA File descriptor 1 - STDOUT - 1 QUEDA LIBRE
				dup(fd);  // File descriptor 1  - arch
					  // File descriptor fd - arch
				close(fd);// CIERRA File descriptor fd - arch - fd QUEDA LIBRE
				return p->exec(__Exec);
			}
			//return 0;
			break;
		case -1: //CODIGO QUE EJECUTA PADRE EN CASO DE ERROR AL HACER fork
			perror("ERROR EN RedirS::exec AL HACER fork !");
			exit(EXIT_FAILURE);
			return -1;
			break;
		default: //CODIGO QUE EJECUTA PADRE EN CASO DE HACER fork SATISFACTORIAMENTE
			wait(&status);
			return status;
			break;
	}
	//return 0;
	return status;
}
int And::exec(enum modo)
{
	int status; //AQUI EL PADRE GUARDA EL STATUS DE TERMINACION DEL HIJO
	if(FORK("And 1")!=0) wait(&status); //PADRE ESPERA A HIJO Y GUARDA STATUS DEL HIJO (OPERADOR IZQ)
	else return i->exec(__Exec);	    //HIJO (OPERADOR IZQUIERDO) EJECUTA SU METODO exec
	if(!WIFEXITED(status) || WEXITSTATUS(status)!=0) //PADRE: SI HIJO TERMINO MAL O STATUS DEL 
		return -1;				 //DEL HIJO DISTINTO DE CERO
	if(FORK("And 2")!=0) wait(&status); //PADRE ESPERA A HIJO Y GUARDA STATUS DEL HIJO (OPERADOR DER)
	else return d->exec(__Exec);	    //HIJO (OPERADOR DERECHO) EJECUTA SU METODO exec
	if(WIFEXITED(status)) 		    //PADRE: SI HIJO TERMINO NORMALMENTE
		return WEXITSTATUS(status); //RETORNA STATUS DEL HIJO
	return -1;	//PADRE: SI HIJO OPERADOR DERECHO TERMINO MAL
}
int Or::exec(enum modo)
{
	// completar
	/* Primera prueba: 17-12-2006 */
	int statusI, statusD;
	if( FORK("OR 1") != 0) wait(&statusI); //PADRE: ESPERA A HIJO (OPERADOR IZQ) Y GUARDA SU statusI
	else return i->exec(__Exec); //HIJO (OPERADOR IZQUIERDO)
	if(!WIFEXITED(statusI) || WEXITSTATUS(statusI) != 0) //SI HIJO (OPERADOR IZQUIERDO) TERMINO MAL
	{
		if( FORK("OR 2") != 0) wait(&statusD); //PADRE: ESPERA A HIJO (OPERADOR DER) Y GUARDA statusD
		else return d->exec(__Exec); //HIJO (OPERADOR DERECHO)
		if(!WIFEXITED(statusD) || WEXITSTATUS(statusD) != 0) //SI HIJO (OPERADOR DERECHO) TERMINO MAL
		{
			exit(EXIT_FAILURE);
			return -1;
		}
		else if(WIFEXITED(statusD)) //SI HIJO (OPERADOR DERECHO) TERMINO NORMALMENTE
		{
			return WEXITSTATUS(statusD);
		}
	}
	else if(WIFEXITED(statusI)) //SI HIJO (OPERADOR IZQUIERDO) TERMINO NORMALMENTE
	{
		if( FORK("OR 2") != 0) wait(&statusD); //PADRE
		else return d->exec(__Exec);
		if(!WIFEXITED(statusD) || WEXITSTATUS(statusD) != 0) //SI HIJO (OPERADOR DERECHO) TERMINO MAL
		{
			return WEXITSTATUS(statusI);
		}
		else if(WIFEXITED(statusD)) //SI HIJO (OPERADOR DERECHO) TAMBIEN TERMINO BIEN
		{
			return WEXITSTATUS(statusD);
		}
	}
	return -1;
}
int Secuencia::exec(enum modo m)
{
	// completar
	/* Primera prueba: 17-12-2006 */
	/* Segunda prueba: 20-12-2006 */
	int statusI, statusD;
	pid_t childpidI, childpidD;
	childpidI = fork();
	cerr << "Secuencia" << " " << childpidI << '\n';
	switch( childpidI )
	{
		case 0:	//CODIGO QUE EJECUTA PROCESO HIJO (OPERADOR IZQUIERDO)
			return i->exec(__Exec);
			break;
		case -1://CODIGO QUE EJECUTA PADRE EN CASO DE ERROR AL HACER fork
			perror("ERROR EN Secuencia::exec DE OPERADOR IZQUIERDO AL HACER fork !");
			exit(EXIT_FAILURE);
			return -1;
			break;
		default://CODIGO QUE EJECUTA PADRE AL HACER fork SATISFACTORIAMENTE
			wait(&statusI);
			cerr <<"PROCESO " << childpidI << " FINALIZADO CON STATUS: " << statusI << '\n';
			//return statusI;
			/* PASE LO QUE PASE CON OPERADOR IZQUIERDO, EJECUTA OPERADOR DERECHO */
			break;
	}
	childpidD = fork();
	cerr << "Secuencia" << " " << childpidD << '\n';
	switch( childpidD )
	{
		case 0:	//CODIGO QUE EJECUTA PROCESO HIJO (OPERADOR DERECHO)
			return d->exec(__Exec);
			break;
		case -1://CODIGO QUE EJECUTA PADRE EN CASO DE ERROR AL HACER fork
			perror("ERROR EN Secuencia::exec DE OPERADOR DERECHO AL HACER fork !");
			exit(EXIT_FAILURE);
			return -1;
			break;
		default://CODIGO QUE EJECUTA PADRE AL HACER fork SATISFACTORIAMENTE
			wait(&statusD);
			return statusD;
			break;
	}
}
int Subshell::exec(enum modo)
{
	// completar
	/* Primera prueba: 17-12-2006 */
	int status;
	pid_t childpid;
	childpid = fork();
	cerr << "Subshell " << childpid << '\n';
	switch( childpid )
	{
		case 0:	//CODIGO QUE EJECUTA PROCESO HIJO 
			return a->exec(__Exec);
			break;
		case -1://CODIGO QUE EJECUTA PROCESO PADRE EN CASO DE ERROR AL HACER fork
			perror("ERROR EN Subshell::exec AL HACER fork !");
			exit(EXIT_FAILURE);
			return -1;
			break;
		default://CODIGO QUE EJECUTA PROCESO PADRE AL HACER fork SATISFACTORIAMENTE
			wait(&status);
			return status;
			break;
	}
	//return status;
}
