#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <sys/wait.h>

void sig_handler(int sig)
{
	if(sig==SIGCHLD) {
		int pid=waitpid(-1, NULL, WNOHANG);
		printf("(%d) termina %d\n", getpid(), pid);
	}
	else printf("auch! %d\n", sig);
}
void error(char *s)
{
	perror(s);
	exit(-1);
}
int main()
{
	int pid;
	struct sigaction action;

	action.sa_handler=sig_handler;
	action.sa_flags=0;
	sigemptyset(&action.sa_mask);
	sigaction(SIGCHLD, &action, NULL);
	if((pid=fork())!=0) { /* padre */
		printf("creado %d\n", pid);
		for(;;);
	}
	else {
		int pid1;
		action.sa_handler=SIG_DFL;
		action.sa_flags=0;
		sigemptyset(&action.sa_mask);
		sigaction(SIGCHLD, &action, NULL);
		if((pid1=fork())!=0) {
			printf("creado %d\n", pid1);
			sleep(1);
			printf("fin! %d\n", getpid());
			exit(0);
		}
		else {
			if(setpgrp()<0) error("setpgrp");
			sleep(3);
			printf("fin! %d\n", getpid());
			exit(0);
		}
	}
	return 0;
}
