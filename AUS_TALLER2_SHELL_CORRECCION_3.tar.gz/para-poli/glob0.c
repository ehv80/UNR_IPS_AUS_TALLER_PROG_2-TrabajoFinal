/*
	Prueba de glob y globfree.
*/
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <glob.h>

int main(int argc, char **argv)
{
	glob_t pg;
	int i;
	pg.gl_offs=0;
	if(glob(argv[1], GLOB_DOOFFS, NULL, &pg)<0) {
		perror("glob");
		exit(-1);
	}
	printf("se encuentran %d\n", pg.gl_pathc);
	for(i=0; pg.gl_pathv[i]!=NULL; i++)
		printf("%s\n", pg.gl_pathv[i]);
	globfree(&pg);
	return 0;
}
